# okmcp

<!-- automd:badges color=yellow -->

[![npm version](https://img.shields.io/npm/v/okmcp?color=yellow)](https://npmjs.com/package/okmcp)
[![npm downloads](https://img.shields.io/npm/dm/okmcp?color=yellow)](https://npm.chart.dev/okmcp)

<!-- /automd -->

Lightweight [Model Context Protocol](https://modelcontextprotocol.io/specification/2026-07-28) (MCP) server utilities for [h3](https://github.com/h3js/h3). Zero MCP SDK dependency. (**~16kb gzip**, dual-era)

One endpoint serves both protocol eras: the stateless `2026-07-28` revision and the `initialize`-based revisions (`2025-11-25`, `2025-06-18`, `2025-03-26`).

> [!WARNING]
> `okmcp` is still evolving and may introduce breaking changes.

👉 [Documentation](https://mcp.h3.dev)

## Quick Start

```sh
npx nypm install h3 okmcp
```

```ts
import { H3, serve } from "h3";
import { defineMcpHandler, defineTool } from "okmcp";

const app = new H3();

app.all(
  "/mcp",
  defineMcpHandler({
    name: "my-server",
    version: "1.0.0",
    tools: [
      defineTool({
        name: "hello",
        description: "Say hello",
        inputSchema: {
          type: "object",
          properties: { name: { type: "string" } },
          required: ["name"],
        },
        handler: async ({ name }) => ({
          content: [{ type: "text", text: `Hello, ${name}!` }],
        }),
      }),
    ],
  }),
);

serve(app, { port: 3000 });
```

<!-- KEEP README MINIMAL, DOCS HAVE MORE DETAILS -->

## Development

<details>

<summary>local development</summary>

- Clone this repository
- Install latest LTS version of [Node.js](https://nodejs.org/en/)
- Enable [Corepack](https://github.com/nodejs/corepack) using `corepack enable`
- Install dependencies using `pnpm install`
- Run interactive tests using `pnpm dev`
- Run the playground using `pnpm play`
- Run the official conformance suite using `pnpm conformance`
- Run the docs site using `pnpm install && pnpm dev` inside `docs/`

</details>

## License

Published under the [MIT](https://github.com/h3js/mcp/blob/main/LICENSE) license.
